<?php

namespace BT\Modules\PaymentTerms\Models;


use Eloquent;

/**
 * Class PaymentTerm
 */
class PaymentTerm extends Eloquent
{

    /**
     * @var bool
     */
    public $timestamps = false;

}
