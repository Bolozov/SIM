<script type="text/javascript">

    $(function () {
        $("#paid_at").datetimepicker({format: '{{ config('bt.dateFormat') }}', timepicker: false, scrollInput: false});
    });

</script>
