<a href="{{ route('employees.edit', [$id]) }}" class="btn btn-secondary btn-sm">
    <i class="fa fa-edit"></i> @lang('bt.edit')</a>
