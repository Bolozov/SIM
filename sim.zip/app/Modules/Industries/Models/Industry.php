<?php

namespace BT\Modules\Industries\Models;

use Eloquent;

/**
 * Class Industry
 */
class Industry extends Eloquent
{
    /**
     * @var bool
     */
    public $timestamps = false;


}
