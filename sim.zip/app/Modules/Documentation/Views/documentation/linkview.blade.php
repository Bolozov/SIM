@extends('documentation.master')

@section('content')

    <div class="col-lg-9 documentation">
        @include($page)
    </div>
@stop
