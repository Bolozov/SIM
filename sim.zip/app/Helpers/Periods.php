<?php

function periods()
{
    return [
        'year_to_date'      => trans('bt.year_to_date'),
        'this_quarter'      => trans('bt.this_quarter'),
        'all_time'          => trans('bt.all_time'),
        'custom_date_range' => trans('bt.custom_date_range')
    ];
}
