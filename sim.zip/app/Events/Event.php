<?php

namespace BT\Events;

abstract class Event
{
    //
}
